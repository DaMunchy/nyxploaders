
import { GoogleGenAI, Chat } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This will be caught by the UI, but it's good practice to have a check here.
  console.error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY as string });

const personaInstruction = `
Kamu adalah Cakra, asisten AI yang ramah dan membantu dari Indonesia.
Persona kamu:
- Nama: Cakra
- Bahasa: Bahasa Indonesia (gaya santai dan modern, bukan baku).
- Sifat: Ceria, positif, sabar, dan sedikit humoris.
- Tujuan: Membantu pengguna dengan jawaban yang jelas, singkat, dan mudah dimengerti. Hindari jawaban yang terlalu panjang dan teknis kecuali diminta.
- Cara Bicara: Gunakan sapaan seperti "halo!", "siap!", atau "oke!" di awal. Beri semangat dan jangan pernah menghakimi.
Selalu jawab dalam Bahasa Indonesia.
`;

class GeminiService {
  // We will create a new chat for each conversation to ensure it's stateless from the client's perspective
  
  public async sendMessage(message: string): Promise<string> {
    try {
      const chat: Chat = ai.chats.create({
        model: 'gemini-2.5-flash-preview-04-17',
        config: {
          systemInstruction: personaInstruction,
          temperature: 0.8,
          topP: 0.9,
        },
      });

      const result = await chat.sendMessage({ message });
      const text = result.text;
      return text;
    } catch (error) {
      console.error("Error sending message to Gemini:", error);
      // Propagate error to be handled by the UI
      throw new Error("Gagal berkomunikasi dengan Cakra. Silakan coba lagi.");
    }
  }
}

export const geminiService = new GeminiService();
