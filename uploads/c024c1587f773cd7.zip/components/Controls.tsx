
import React from 'react';
import { AppStatus } from '../types';

interface ControlsProps {
  status: AppStatus;
  start: () => void;
  stop: () => void;
  isUnsupported: boolean;
}

const MicrophoneIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
    </svg>
);

export const Controls: React.FC<ControlsProps> = ({ status, start, stop, isUnsupported }) => {
  const isListening = status === AppStatus.LISTENING;
  const isProcessing = status === AppStatus.THINKING || status === AppStatus.SPEAKING;
  const hasError = status === AppStatus.ERROR;

  const getButtonText = () => {
    if (isUnsupported) return "Browser Tidak Didukung";
    switch (status) {
      case AppStatus.LISTENING:
        return "Mendengarkan...";
      case AppStatus.THINKING:
        return "Sedang berpikir...";
      case AppStatus.SPEAKING:
        return "Berbicara...";
      case AppStatus.ERROR:
        return "Coba Lagi";
      default:
        return "Tahan untuk Bicara";
    }
  };
  
  const handleMouseDown = (e: React.MouseEvent | React.TouchEvent) => {
    if (status === AppStatus.IDLE || status === AppStatus.ERROR) {
      e.preventDefault();
      start();
    }
  };
  
  const handleMouseUp = (e: React.MouseEvent | React.TouchEvent) => {
    if (isListening) {
      e.preventDefault();
      stop();
    }
  };

  const isDisabled = isProcessing || isUnsupported;

  return (
    <div className="flex flex-col items-center justify-center space-y-4">
      <button
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onTouchStart={handleMouseDown}
        onTouchEnd={handleMouseUp}
        disabled={isDisabled}
        className={`relative flex items-center justify-center w-24 h-24 rounded-full text-white transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-cyan-500/50
          ${isListening ? 'bg-red-500 scale-110' : hasError ? 'bg-amber-600' : 'bg-cyan-500'}
          ${isProcessing ? 'cursor-not-allowed bg-gray-600' : hasError ? 'hover:bg-amber-700' : 'hover:bg-cyan-600'}
          ${isUnsupported ? 'bg-red-800 cursor-not-allowed' : ''}
        `}
      >
        <MicrophoneIcon />
      </button>
      <p className="text-gray-400 text-center min-h-[24px] w-48">{getButtonText()}</p>
    </div>
  );
};
