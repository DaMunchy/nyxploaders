
import React from 'react';
import { AppStatus } from '../types';

interface AvatarProps {
  status: AppStatus;
}

const Eye = ({ cx, cy }: { cx: number; cy: number }) => (
    <g>
        <circle cx={cx} cy={cy} r="10" fill="url(#eyeGradient)" />
        <defs>
            <radialGradient id="eyeGradient">
                <stop offset="0%" stopColor="#80FFFF" />
                <stop offset="100%" stopColor="#00FFFF" />
            </radialGradient>
        </defs>
        <circle cx={cx} cy={cy} r="4" fill="#111827" />
    </g>
);


export const Avatar: React.FC<AvatarProps> = ({ status }) => {
  const isSpeaking = status === AppStatus.SPEAKING;
  const isListening = status === AppStatus.LISTENING;
  const isThinking = status === AppStatus.THINKING;

  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80 flex items-center justify-center">
        {/* Outer Listening Glow */}
        <div className={`absolute w-full h-full rounded-full bg-cyan-500/20 transition-all duration-500 ${isListening ? 'scale-110 opacity-100' : 'scale-90 opacity-0'}`}>
             {isListening && <div className="absolute w-full h-full rounded-full bg-cyan-500/20 animate-ping"></div>}
        </div>
        
        {/* Thinking Spinner */}
        <div className={`absolute w-full h-full rounded-full border-4 border-dashed border-cyan-400 transition-opacity duration-300 ${isThinking ? 'opacity-100 animate-spin' : 'opacity-0'}`} style={{animationDuration: '3s'}}></div>

        <div className="relative w-full h-full">
            <svg viewBox="0 0 200 200" className="w-full h-full">
                {/* Main Face */}
                <circle cx="100" cy="100" r="90" fill="url(#avatarGradient)" stroke="#00FFFF" strokeWidth="1" strokeOpacity="0.5" />
                <defs>
                <radialGradient id="avatarGradient" cx="0.5" cy="0.5" r="0.5">
                    <stop offset="0%" stopColor="#252A34" />
                    <stop offset="100%" stopColor="#111827" />
                </radialGradient>
                </defs>

                {/* Eyes */}
                <Eye cx={75} cy={85} />
                <Eye cx={125} cy={85} />
               
                {/* Mouth */}
                <path
                    d={`M 75 130 Q 100 ${isSpeaking ? 145 : 130}, 125 130`}
                    fill="none"
                    stroke="#00FFFF"
                    strokeWidth="3"
                    strokeLinecap="round"
                    className="transition-all duration-150 ease-in-out"
                />
            </svg>
        </div>
    </div>
  );
};
