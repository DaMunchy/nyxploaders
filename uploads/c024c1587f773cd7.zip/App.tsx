
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AppStatus, ChatMessage, ChatRole } from './types';
import { useSpeechToText } from './hooks/useSpeechToText';
import { useTextToSpeech } from './hooks/useTextToSpeech';
import { geminiService } from './services/geminiService';
import { Avatar } from './components/Avatar';
import { Controls } from './components/Controls';
import { ChatBubble } from './components/ChatBubble';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const handleNewTranscript = useCallback(async (transcript: string) => {
    if (!transcript) {
      setStatus(AppStatus.IDLE);
      return;
    }

    setStatus(AppStatus.THINKING);
    const userMessage: ChatMessage = { role: ChatRole.USER, text: transcript };
    setMessages(prev => [...prev, userMessage]);

    try {
      const aiResponseText = await geminiService.sendMessage(transcript);
      
      const aiMessage: ChatMessage = { role: ChatRole.ASSISTANT, text: aiResponseText };
      setMessages(prev => [...prev, aiMessage]);

      setStatus(AppStatus.SPEAKING);
      speak(aiResponseText, () => {
        setStatus(AppStatus.IDLE);
      });
    } catch (e) {
        console.error(e);
        setError("An error occurred. Please try again.");
        setStatus(AppStatus.ERROR);
    }
  }, []);

  const { isListening, startListening, stopListening, isSupported: sttSupported } = useSpeechToText(handleNewTranscript);
  const { speak, isSpeaking, isSupported: ttsSupported } = useTextToSpeech();
  
  useEffect(() => {
    if (isListening) {
      setStatus(AppStatus.LISTENING);
    } else if (status === AppStatus.LISTENING) {
      // This case handles when listening stops without a result (e.g. timeout)
      setStatus(AppStatus.IDLE);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isListening]);

  useEffect(() => {
    if(chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const isUnsupported = !sttSupported || !ttsSupported || !process.env.API_KEY;
  
  const getInitialMessage = () => {
      if (isUnsupported) {
          if (!process.env.API_KEY) {
              return { role: ChatRole.ASSISTANT, text: "Kunci API Gemini belum diatur. Silakan atur variabel lingkungan API_KEY." };
          }
           if (!sttSupported || !ttsSupported) {
              return { role: ChatRole.ASSISTANT, text: "Maaf, browser kamu tidak mendukung fitur suara yang dibutuhkan." };
           }
      }
      return { role: ChatRole.ASSISTANT, text: "Halo! Saya Cakra. Tahan tombol di bawah untuk mulai berbicara dengan saya." };
  }

  useEffect(() => {
      setMessages([getInitialMessage()]);
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startInteraction = () => {
    if (status === AppStatus.ERROR) {
        setError(null);
        setStatus(AppStatus.IDLE);
        // Reset to initial message if there's an error
        setMessages([getInitialMessage()]);
    } else {
        startListening();
    }
  };


  return (
    <div className="flex flex-col h-screen w-full bg-gray-900 text-white overflow-hidden">
      <header className="p-4 text-center border-b border-gray-700">
        <h1 className="text-2xl font-bold text-cyan-400">Cakra AI</h1>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-end p-4 overflow-hidden">
        {messages.length <= 1 && (
             <div className="flex-1 flex items-center justify-center">
                <Avatar status={status} />
             </div>
        )}

        {messages.length > 1 && (
            <div ref={chatContainerRef} className="w-full flex-1 overflow-y-auto space-y-6 pb-4 scroll-smooth">
                 {messages.map((msg, index) => (
                    <ChatBubble key={index} message={msg} />
                ))}
            </div>
        )}
      </main>

      <footer className="p-6 bg-gray-900/50 backdrop-blur-sm border-t border-gray-700">
        <Controls 
          status={status} 
          start={startInteraction} 
          stop={stopListening}
          isUnsupported={isUnsupported}
        />
        {error && <p className="text-red-500 text-center mt-2">{error}</p>}
      </footer>
    </div>
  );
};

export default App;
