
export enum AppStatus {
  IDLE = "IDLE",
  LISTENING = "LISTENING",
  THINKING = "THINKING",
  SPEAKING = "SPEAKING",
  ERROR = "ERROR",
}

export enum ChatRole {
  USER = "USER",
  ASSISTANT = "ASSISTANT",
}

export interface ChatMessage {
  role: ChatRole;
  text: string;
}
