
import { useState, useEffect, useRef, useCallback } from 'react';

// Define a minimal interface for the SpeechRecognition instance to provide type safety.
// We are keeping event types as `any` for simplicity, as their full structure is complex.
interface ISpeechRecognition extends EventTarget {
  continuous: boolean;
  lang: string;
  interimResults: boolean;
  start(): void;
  stop(): void;
  onresult: (event: any) => void;
  onend: () => void;
  onerror: (event: any) => void;
}

// Cast `window` to `any` to access non-standard properties (`SpeechRecognition`, `webkitSpeechRecognition`).
// Assign it to a new variable `SpeechRecognitionAPI` to avoid shadowing a potential `SpeechRecognition` type.
const SpeechRecognitionAPI =
  (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

export const useSpeechToText = (onTranscript: (transcript: string) => void) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  // Use our custom interface for the ref. This resolves the TypeScript error.
  const recognitionRef = useRef<ISpeechRecognition | null>(null);

  useEffect(() => {
    if (!SpeechRecognitionAPI) {
      setIsSupported(false);
      return;
    }

    // Create an instance of the Speech Recognition API.
    const recognition: ISpeechRecognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.lang = 'id-ID';
    recognition.interimResults = false;

    recognition.onresult = (event: any) => {
      const transcript = event.results[event.results.length - 1][0].transcript.trim();
      if (transcript) {
        onTranscript(transcript);
      }
    };
    
    recognition.onend = () => {
      if (recognitionRef.current) { // Check if it's still mounted
        setIsListening(false);
      }
    };
    
    recognition.onerror = (event: any) => {
      console.error('SpeechRecognition error', event.error);
       if (recognitionRef.current) { // Check if it's still mounted
        setIsListening(false);
      }
    };

    recognitionRef.current = recognition;

    return () => {
      // Cleanup on unmount
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
    };
  }, [onTranscript]);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (error) {
        console.error("Error starting speech recognition:", error);
        setIsListening(false);
      }
    }
  }, [isListening]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, [isListening]);

  return { isListening, startListening, stopListening, isSupported };
};
